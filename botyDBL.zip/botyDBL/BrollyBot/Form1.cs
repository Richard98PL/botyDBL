﻿using Memory;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrollyBot
{
    public partial class Form1 : Form
    {
        public static Mem m = new Mem();
        static int pID;

        public static Process DBLProcess = Process.GetProcessesByName("DBLClient").FirstOrDefault();

        [DllImport("User32.dll")]
        static extern int SetForegroundWindow(IntPtr point);

        static Random rnd = new Random();
        static int lag;

        static double playerHP;
        static double playerMana;

        static int hpTick = 0;
        static int manaTick = 0;

        System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"danger.wav");
        public Form1()
        {
            
            InitializeComponent();
            pID = m.getProcIDFromName("DBLCLient");
            bool openProc = false;
            if (pID > 0) openProc = m.OpenProcess(pID);

            label3.Text = "hp adr";
            label4.Text = "mana adr";
            textBox1.Text = "F1234567";
            textBox2.Text = "F1234567";
            button1.Text = "go heal [F3] or last spell [F4]";
            button2.Text = "go senzu [F7]";

            label1.Text = "hp ticks : 0";
            label2.Text = "mana ticks : 0";

            textBox3.Text = "hp : 0";
            textBox4.Text = "mana : 0";
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;

            label5.Text = "hp to heal";
            label6.Text = "mana to senzu";

            textBox5.Text = "2000";
            textBox6.Text = "1000";

            timer3.Enabled = true;
            checkBox1.Text = "sound off";


            System.Windows.Forms.MessageBox.Show("Client name must be DBLClient \n Have fun! \n \t\t by SilesiaTeam \n \t\t     11.08.2019");


        }

        private void Button1_Click(object sender, EventArgs e)
        {

            if (button1.Text == "go heal [F3] or last spell [F4]")
            {
                button1.Text = "stop";
                if (timer1.Enabled == false) timer1.Enabled = true;
                ChangeTextBox(textBox1);
                ChangeTextBox(textBox5);
            }
            else
            {
                button1.Text = "go heal [F3] or last spell [F4]";
                if (timer1.Enabled) timer1.Enabled = false;
                ChangeTextBox(textBox1);
                ChangeTextBox(textBox5);
            }
            
        }

        private  void ChangeTextBox(TextBox x)
        {
            if (x.Enabled) x.Enabled = false;
            else x.Enabled = true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {

            if (button2.Text == "go senzu [F7]")
            {
                button2.Text = "stop";
                if (timer2.Enabled == false) timer2.Enabled = true;
                ChangeTextBox(textBox2);
                ChangeTextBox(textBox6);
            }
            else
            {
                button2.Text = "go senzu [F7]";
                if (timer2.Enabled) timer2.Enabled = false;
                ChangeTextBox(textBox2);
                ChangeTextBox(textBox6);
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            hpTick++;
            label1.Text = "hp ticks : " + hpTick.ToString();

            if(playerHP < Double.Parse(textBox5.Text))
            {
                if(DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);

                    lag = rnd.Next(0, 300);
                    Thread.Sleep(lag);
                    SendKeys.Send("{F3}");
                    if (playerHP < 0.7 * Double.Parse(textBox5.Text)) SendKeys.Send("{F7}");

                }
            }
            else
            {
                if (DBLProcess != null)
                {
                    if (playerMana > 6000)
                    {
                        IntPtr h = DBLProcess.MainWindowHandle;
                        SetForegroundWindow(h);

                        lag = rnd.Next(0, 300);
                        Thread.Sleep(lag);
                        SendKeys.Send("{F4}");
                    }
                    else
                    {
                        
                    }
                }
            }
            
        }

        private void Label2_Click(object sender, EventArgs e)
        {
           
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            manaTick++;
            label2.Text = "mana ticks : " + manaTick.ToString();

            if (playerMana < Double.Parse(textBox6.Text))
            {
                if (DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);

                    lag = rnd.Next(0, 300);
                    Thread.Sleep(lag);
                    SendKeys.Send("{F7}");
                }
            }
            

        }

        static bool isMusicOn = false;
        private void Timer3_Tick(object sender, EventArgs e)
        {
            playerMana = m.readDouble(textBox2.Text);
            playerHP = m.readDouble(textBox1.Text);
            textBox3.Text = "hp : " + playerHP.ToString();
            textBox4.Text = "mana : " + playerMana.ToString();

            if (playerHP < 1 && button1.Text.Equals("stop") && !isMusicOn) 
            {
                player.PlayLooping();
                isMusicOn = true;
                button1.PerformClick();
                button2.PerformClick();
            }

            if(playerMana < 3000 && button2.Text.Equals("stop") && !isMusicOn)
            {
                player.PlayLooping();
                isMusicOn = true;
            }
            if (isMusicOn)
            {
                if(playerMana > 3000)
                {
                    player.Stop();
                    isMusicOn = false;
                }
                
            }

            if (checkBox1.Checked)
            {
                player.Stop();
                isMusicOn = false;
            }
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            playerMana = m.readDouble(textBox2.Text);
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            playerHP = m.readDouble(textBox1.Text);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }
    }
}
