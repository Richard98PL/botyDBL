﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Threading;

namespace moveBot
{
    public partial class Form1 : Form
    {
        static Label statycznyLabel1;
        static Button statycznyButton2;
       

        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private static LowLevelKeyboardProc _proc = HookCallback;
        private static IntPtr _hookID = IntPtr.Zero;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        public static Process DBLProcess = Process.GetProcessesByName("DBLClient").FirstOrDefault();

        [DllImport("User32.dll")]
        static extern int SetForegroundWindow(IntPtr point);

        static Random rnd = new Random();
        static int lag;


        public Form1()
        {
            
            _hookID = SetHook(_proc);
            InitializeComponent();
            // UnhookWindowsHookEx(_hookID);
            timer1.Enabled = false;

            button1.Text = "record keys";
            button2.Text = "play";
            textBox1.Text = "500";
            button3.Text = "reset";

            statycznyLabel1 = label1;
            statycznyButton2 = button2;
            button3.Enabled = false;
            label1.Text = "key";
            label2.Text = "'x' to stop";

        }

        private static IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc,
                    GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        public static List<String> lista = new List<String>();
        private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN)
            {
                int vkCode = Marshal.ReadInt32(lParam);
                Console.Write((Keys)vkCode);
                Console.Write(vkCode);
                Console.WriteLine();
                
                switch (vkCode)
                {
                    case 37:
                        statycznyLabel1.Text = "Left"; break;
                    case 38:
                        statycznyLabel1.Text = "Up"; break;
                    case 39:
                        statycznyLabel1.Text = "Right"; break;
                    case 40:
                        statycznyLabel1.Text = "Down"; break;
                    case 88:
                        statycznyButton2.PerformClick();break;
                }

                if (isRecording && (vkCode==37 || vkCode == 38 || vkCode == 39 || vkCode == 40) ) lista.Add(statycznyLabel1.Text);
            }

            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        static int indeksListy = 0;
        private void Timer1_Tick(object sender, EventArgs e)
        {
            if(lista.Count == 0)
            {

            }
            else
            {
                if (DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);

                   // lag = rnd.Next(0, 300);
                    // Thread.Sleep(lag);
                    SendKeys.Send("{" + lista.ElementAt(indeksListy) + "}");
                    indeksListy++;
                    if (indeksListy == lista.Count) indeksListy = 0;
                    label1.Text = lista.ElementAt(indeksListy);
                }
            }

        }

        static bool isRecording = false;
        static bool isPlaying = false;
        private void Button1_Click(object sender, EventArgs e)
        {
            if(button1.Text == "record keys")
            {
                button1.Text = "stop";
                isRecording = true;
                button2.Enabled = false;
            }else
            {
                button1.Text = "record keys";
                isRecording = false;
                button2.Enabled = true;
                button1.Enabled = false;
                button3.Enabled = true;
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if(button2.Text == "play")
            {
                button2.Text = "stop";
                isPlaying = true;
                button1.Enabled = false;
                if (timer1.Enabled == false) timer1.Enabled = true;
                button3.Enabled = false;
               
                

            }
            else
            {
                button2.Text = "play";
                isPlaying = false;
                if (timer1.Enabled) timer1.Enabled = false;
                button3.Enabled = true;
                indeksListy = 0;



            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            timer1.Interval = Int32.Parse(textBox1.Text);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            lista.Clear();
            indeksListy = 0;
            button1.Enabled = true;
            button3.Enabled = false;
        }
    }


}

