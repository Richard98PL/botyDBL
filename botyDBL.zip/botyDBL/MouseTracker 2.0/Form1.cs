﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Speech.Synthesis;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MouseTracker_2._0
{
    public partial class Form1 : Form
    {
        int rozmiarArrayListy = 0;
        int X;
        int Y;

        Random rnd = new Random();
        static Boolean perfectly = false;
        bool isCurrentlyRecording = false;
        bool isChoosingColor = false;
        List<Point> al = new List<Point>();
        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        //Mouse actions
        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        public Form1()
        {
            InitializeComponent();
            button2.Enabled = false;
            textBox1.Text = "2000";

            MouseHook.Start();
            MouseHook.MouseAction += new EventHandler(Event);
            

        }


        private void Event(object sender, EventArgs e) {

            if (isCurrentlyRecording)
            {
                al.Add(new Point(Cursor.Position.X, Cursor.Position.Y));
                al.Add(new Point(Cursor.Position.X, Cursor.Position.Y));
                rozmiarArrayListy = al.Count;
            }
            if (isChoosingColor)
            {
                isChoosingColor = false;
                Color pxl = GetColorFromScreen(new Point(Cursor.Position.X, Cursor.Position.Y));
                label2.Text = pxl.ToString();
                button3.Text = "CHOOSE PIXEL TO DETECT";
                label3.Text = Cursor.Position.X + ", " + Cursor.Position.Y;
                X = Cursor.Position.X;
                Y = Cursor.Position.Y;


                timer2.Enabled = true;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "RECORD")
            {
                button1.Text = "STOP RECORDING";
                button2.Enabled = false;

                isCurrentlyRecording = true;
                al.Clear();
            }
            else
            {
                button1.Text = "RECORD";
                button2.Enabled = true;

                isCurrentlyRecording = false;
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "PLAY")
            {
                button2.Text = "STOP";
                timer1.Enabled = true;
            }
            else
            {
                button2.Text = "PLAY";
                timer1.Enabled = false;
            }
            }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        int nextPoint = 0;


        private void Timer1_Tick(object sender, EventArgs e)
        {

            int randomNumber = rnd.Next(-5, 5);
            int X;
            int Y;
            if (perfectly) {
                X = al.ElementAt(nextPoint).X;
                Y = al.ElementAt(nextPoint).Y;
            }
            else
            {
                X = al.ElementAt(nextPoint).X + randomNumber;
                Y = al.ElementAt(nextPoint).Y + randomNumber;
            }
            
          

            SetCursorPos(X,Y);
            Thread.Sleep(150);
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, X, Y, 0, 0);

            nextPoint++;

            if (nextPoint == rozmiarArrayListy-1)
            {
                nextPoint = 0;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            timer1.Interval = Convert.ToInt32(textBox1.Text);
            if (Convert.ToInt32(textBox1.Text) < 500)
            {
                button2.Enabled = false;
            }
            else button2.Enabled = true;
        }

        static String pxl;
        private void Button3_Click(object sender, EventArgs e)
        {
            isChoosingColor = true;
            button3.Text = "IS CHOOSING";
            
        }
        public Color GetColorFromScreen(Point p)
        {
            Rectangle rect = new Rectangle(p, new Size(2, 2));

            Bitmap map = CaptureFromScreen(rect);

            Color c = map.GetPixel(0, 0);

            map.Dispose();

            return c;
        }
        public Bitmap CaptureFromScreen(Rectangle rect)
        {
            Bitmap bmpScreenCapture = null;

            if (rect == Rectangle.Empty)//capture the whole screen
            {
                rect = Screen.PrimaryScreen.Bounds;
            }

            bmpScreenCapture = new Bitmap(rect.Width, rect.Height);

            Graphics p = Graphics.FromImage(bmpScreenCapture);


            p.CopyFromScreen(rect.X,
                     rect.Y,
                     0, 0,
                     rect.Size,
                     CopyPixelOperation.SourceCopy);


            p.Dispose();

            return bmpScreenCapture;
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            Color pxl2 = GetColorFromScreen(new Point(X,Y));
            label4.Text = pxl2.ToString();
            if (isSoundOn && !pxl2.ToString().Equals(label2.Text))
            {

                SpeechSynthesizer synth = new SpeechSynthesizer();
                synth.SelectVoiceByHints(VoiceGender.Male, VoiceAge.Senior);
                synth.SpeakAsync("HEY");


            }
        }
        Boolean isSoundOn = false;
        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            isSoundOn = !isSoundOn;
        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            perfectly = !perfectly;
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
    }

    public static class MouseHook

    {
        public static event EventHandler MouseAction = delegate { };

        public static void Start()
        {
            _hookID = SetHook(_proc);


        }
        public static void stop()
        {
            UnhookWindowsHookEx(_hookID);
        }

        private static LowLevelMouseProc _proc = HookCallback;
        private static IntPtr _hookID = IntPtr.Zero;

        private static IntPtr SetHook(LowLevelMouseProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_MOUSE_LL, proc,
                  GetModuleHandle(curModule.ModuleName), 0);
            }

            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc,
                    GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
        private const int WM_KEYDOWN = 0x0100;
        private static IntPtr HookCallback(
          int nCode, IntPtr wParam, IntPtr lParam)
        {
            

        
            if (nCode >= 0 && MouseMessages.WM_RBUTTONDOWN == (MouseMessages)wParam)
            {
                MSLLHOOKSTRUCT hookStruct = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));
                MouseAction(null, new EventArgs());
            }

            if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN)
            {
                int vkCode = Marshal.ReadInt32(lParam);
                Console.Write((Keys)vkCode);
                Console.Write(vkCode);
                Console.WriteLine();
                
            }
            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        private const int WH_MOUSE_LL = 14;

        private enum MouseMessages
        {
            WM_LBUTTONDOWN = 0x0201,
            WM_LBUTTONUP = 0x0202,
            WM_MOUSEMOVE = 0x0200,
            WM_MOUSEWHEEL = 0x020A,
            WM_RBUTTONDOWN = 0x0204,
            WM_RBUTTONUP = 0x0205
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int x;
            public int y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MSLLHOOKSTRUCT
        {
            public POINT pt;
            public uint mouseData;
            public uint flags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook,
          LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode,
          IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);


    }
}
