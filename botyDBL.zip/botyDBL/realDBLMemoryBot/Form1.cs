﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Memory;

namespace realDBLMemoryBot
{
    public partial class Form1 : Form
    {
        public static Mem m = new Mem();
        static int pID;

        static Boolean isHpAdressEmpty = true;
        static Boolean isManaAdressEmpty = true;
        static Boolean isHpLimitEmpty = true;
        static Boolean isManaLimitEmpty = true;
        static Boolean isFurieOn = false;
        static Boolean isTargetOn = false;
        static Boolean isPowerDownOn = false;
        static double PlayerHp = 0;
        static double PlayerMana = 0;
        static double PlayerFurie = 0;

        static Boolean isAutoHealEnabled = false;
        static Boolean isAutoSenzuEnabled = false;

        static String choosedSpellButton = "F3";
        static String choosedSenzuButton = "F7";
        static String choosedFurieButton = "F5";
        static String choosedTargetButton = "F10";
        static String choosedLastSpellButton = "F1";
        static String choosedPowerDownButton = "F2";

        public static Process DBLProcess = Process.GetProcessesByName("DBLClient").FirstOrDefault();

        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        private static extern bool SetCursorPos(int X, int Y);

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        //Mouse actions
        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;


        [DllImport("User32.dll")]
        static extern int SetForegroundWindow(IntPtr point);

        static Random rnd = new Random();
        static int lag;

        public Form1()
        {
            InitializeComponent();
            pID = m.getProcIDFromName("DBLClient");
            bool openProc = false;
            if (pID > 0) openProc = m.OpenProcess(pID);
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button5.Enabled = false;

            textBox3.Enabled = false;
            textBox4.Enabled = false;

            comboBox1.SelectedIndex = 2;
            comboBox2.SelectedIndex = 6;
            comboBox3.SelectedIndex = 4;
            comboBox4.SelectedIndex = 9;
            comboBox5.SelectedIndex = 0;
            comboBox6.SelectedIndex = 1;

            comboBox1.Enabled = false;
            comboBox2.Enabled = false;
            comboBox3.Enabled = false;
            textBox6.Text = "2400";
            textBox3.Text = "21000";
            textBox4.Text = "12000";
            button2.Enabled = false;
            button3.Enabled = false;

            timer1.Tick += new EventHandler(onBotRefresh);
            timer2.Tick += new EventHandler(onRealBotRefresh);

            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = false;
            Tickz1 = 0;
            richTextBox1.Text = "";
            Tickzz2 = 0;
            


            isAutoSenzuEnabled = false;
            isAutoHealEnabled = false;

            if (button2.Text == "stop autoheal")
            {
                textBox3.Enabled = true;
                comboBox1.Enabled = true;
                button2.Text = "run autoheal";
            }

            if (button3.Text == "stop autosenzu")
            {
                textBox4.Enabled = true;
                comboBox2.Enabled = true;
                button3.Text = "run autosenzu";
            }

            if (button5.Text == "stop autofurie")
            {
                comboBox3.Enabled = true;
                button3.Text = "run autofurie";
            }





        }

        private void onBotRefresh(object sender, EventArgs e)
        {

            richTextBox1.Text += DateTime.Now.ToString("H:mm:ss") + "  hp : " + m.readDouble(textBox1.Text) + "   mana : " + m.readDouble(textBox2.Text) + "\n";


        }

        static int Tickzz2 = 0;
        static int ktoreWejscie = 0;
        static int polSekundnik = 0;
        private void onRealBotRefresh(object sender, EventArgs e)
        {

            lag = rnd.Next(100, 300);


            PlayerHp = m.readDouble(textBox1.Text);
            PlayerMana = m.readDouble(textBox2.Text);
            PlayerFurie = m.readDouble(textBox5.Text);


            // Point mycha = new Point(Cursor.Position.X, Cursor.Position.Y);
            //  SetCursorPos(1736, 142);
            // int X = Cursor.Position.X;
            // int Y = Cursor.Position.Y;
            // Thread.Sleep(1);
            // mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, X, Y, 0, 0);
            // SetCursorPos(mycha.X, mycha.Y);



            double ustawioneHP = Double.Parse(textBox3.Text);


            if (isAutoHealEnabled)
            {
                if (Tickzz2 != 27) Tickzz2++;
                else
                {         
                    richTextBox1.Text = "";
                }

                if (PlayerHp < Double.Parse(textBox3.Text))
                {
                    if (DBLProcess != null)
                    {
                        richTextBox1.Text.Insert(0,DateTime.Now.ToString("H:mm:ss") + "  hp : " + m.readDouble(textBox1.Text) + "   mana : " + m.readDouble(textBox2.Text) + "\n");
                        IntPtr h = DBLProcess.MainWindowHandle;
                        SetForegroundWindow(h);
                        Thread.Sleep(lag);
                        SendKeys.SendWait("{" + choosedSpellButton + "}");
                        Thread.Sleep(5);
                        if(PlayerHp < ustawioneHP/ 1.5) SendKeys.SendWait("{" + choosedSenzuButton + "}");
                    }
                }
            }

            if (isAutoSenzuEnabled)
            {
                if (PlayerMana < Double.Parse(textBox4.Text))
                {
                    if (DBLProcess != null)
                    {
                        richTextBox1.Text.Insert(0, DateTime.Now.ToString("H:mm:ss") + "  hp : " + m.readDouble(textBox1.Text) + "   mana : " + m.readDouble(textBox2.Text) + "\n");
                        IntPtr h = DBLProcess.MainWindowHandle;
                        SetForegroundWindow(h);
                        Thread.Sleep(lag);
                        SendKeys.SendWait("{" + choosedSenzuButton + "}");
                        Thread.Sleep(5);
                    }
                }
            }
        }



        public static int Tickz1 = 0;
        private void Timer1_Tick(object sender, EventArgs e)
        {
            Tickz1++;
            if (Tickz1 == 27)
            {
                timer1.Enabled = false;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                comboBox1.Enabled = true;
                comboBox2.Enabled = true;
                comboBox3.Enabled = true;
                button5.Enabled = true;

                if(timer2.Enabled == false)timer2.Enabled = true;
                if (timer3.Enabled == false) timer3.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;

            }
          }

            private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length>0) isManaAdressEmpty = false;
            else isManaAdressEmpty = true;
            if (isHpAdressEmpty == false && isManaAdressEmpty == false) button1.Enabled = true;
            if (isHpAdressEmpty || isManaAdressEmpty) button1.Enabled = false;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length>0) isHpAdressEmpty = false;
            else isHpAdressEmpty = true;
            if (isHpAdressEmpty == false && isManaAdressEmpty == false) button1.Enabled = true;
            if (isHpAdressEmpty || isManaAdressEmpty) button1.Enabled = false;
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text.Length > 0) isHpLimitEmpty = false;
            else isHpLimitEmpty = true;
            if (isHpLimitEmpty) button2.Enabled = false;
            else button2.Enabled = true;
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text.Length > 0) isManaLimitEmpty = false;
            else isManaLimitEmpty = true;
            if (isManaLimitEmpty) button3.Enabled = false;
            else button3.Enabled = true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "run autoheal")
            {
                textBox3.Enabled = false;
                comboBox1.Enabled = false;
                button2.Text = "stop autoheal";
            }
            else
            {
                textBox3.Enabled = true;
                comboBox1.Enabled = true;
                button2.Text = "run autoheal";
            }

            Tickzz2 = 0;

            isAutoHealEnabled = !isAutoHealEnabled;

            richTextBox1.Text = "";
        }

        private void Button3_Click(object sender, EventArgs e)
        {

            
            if (button3.Text == "run autosenzu")
            {
                textBox4.Enabled = false;
                comboBox2.Enabled = false;
                button3.Text = "stop autosenzu";
            }
            else
            {
                textBox4.Enabled = true;
                comboBox2.Enabled = true;
                button3.Text = "run autosenzu";
            }

            Tickz1 = 0;
            isAutoSenzuEnabled = !isAutoSenzuEnabled;
        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Timer2_Tick(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedSpellButton = comboBox1.GetItemText(comboBox1.SelectedItem);
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedSenzuButton = comboBox2.GetItemText(comboBox2.SelectedItem);
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            Form2 tutorial = new Form2();
            tutorial.Show();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            isFurieOn = !isFurieOn;
            if (button5.Text == "run autofurie")
            {
                comboBox3.Enabled = false;
                button5.Text = "stop autofurie";
            }
            else
            {
                comboBox3.Enabled = true;
                button5.Text = "run autofurie";
            }
        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void ComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedFurieButton = comboBox3.GetItemText(comboBox3.SelectedItem);
        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            lag = rnd.Next(100, 300);


            PlayerHp = m.readDouble(textBox1.Text);
            PlayerMana = m.readDouble(textBox2.Text);
            PlayerFurie = m.readDouble(textBox5.Text);


            if (isFurieOn)
            {
                if (PlayerFurie < 98)
                {
                    if (DBLProcess != null)
                    {
                        IntPtr h = DBLProcess.MainWindowHandle;
                        SetForegroundWindow(h);
                        Thread.Sleep(lag);
                        SendKeys.SendWait("{" + choosedFurieButton + "}");
                        Thread.Sleep(5);
                    }
                }

            }

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            isTargetOn = !isTargetOn;
            if (button6.Text == "run cavebot")
            {
                comboBox4.Enabled = false;
                textBox6.Enabled = false;
                button6.Text = "stop cavebot";
                if(timer4.Enabled == false)timer4.Enabled = true;
                if (timer5.Enabled == false) timer5.Enabled = true;
                comboBox5.Enabled = false;
            }
            else
            {
                comboBox5.Enabled = true;
                comboBox4.Enabled = true;
                textBox6.Enabled = true;
                button6.Text = "run cavebot";
                if (timer4.Enabled == true) timer4.Enabled = false;
                if (timer5.Enabled == true) timer5.Enabled = false;
            }


             
        }

        private void Timer4_Tick(object sender, EventArgs e)
        {
            lag = rnd.Next(100, 300);

            if (isTargetOn)
            {
                if (DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);
                    Thread.Sleep(lag);
                    SendKeys.SendWait("{" + choosedTargetButton + "}");
                    Thread.Sleep(5);
                }

            }
        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {
            timer4.Interval = Convert.ToInt32(textBox6.Text);
        }

        private void Timer5_Tick(object sender, EventArgs e)
        {
            lag = rnd.Next(100, 300);
            PlayerHp = m.readDouble(textBox1.Text);
            
            double ustawioneHP =  Double.Parse(textBox3.Text);
            
            if (isLastSpell && PlayerHp >= ustawioneHP/2 && PlayerHp < ustawioneHP)
            {
                if (DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);
                    Thread.Sleep(lag);
                    SendKeys.SendWait("{" + choosedLastSpellButton + "}");
                    Thread.Sleep(5);
                }
            }
           
        }

        private void ComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedTargetButton = comboBox4.GetItemText(comboBox4.SelectedItem);
        }

        private void ComboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedLastSpellButton = comboBox5.GetItemText(comboBox5.SelectedItem);
        }

        private void Button7_Click(object sender, EventArgs e)
        {

        }

        Boolean isLastSpell = false;
        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            isLastSpell = !isLastSpell;
        }

        private void Button7_Click_1(object sender, EventArgs e)
        {
            if(button7.Text == "run training")
            {
                isPowerDownOn = true;
                button7.Text = "stop training";
                if(timer6.Enabled == false)timer6.Enabled = true;
                
            }
            else
            {
                isPowerDownOn = false;
                button7.Text = "run training";
                if (timer6.Enabled == true) timer6.Enabled = false;
            }

           
        }

        private void ComboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            choosedPowerDownButton = comboBox6.GetItemText(comboBox6.SelectedItem);
        }

        private void Timer6_Tick(object sender, EventArgs e)
        {
            lag = rnd.Next(100, 300);
            PlayerMana = m.readDouble(textBox2.Text);
            double ustawionaManaPowerDown = Double.Parse(textBox7.Text);
            if (isPowerDownOn && PlayerMana >= ustawionaManaPowerDown)
            {
                if (DBLProcess != null)
                {
                    IntPtr h = DBLProcess.MainWindowHandle;
                    SetForegroundWindow(h);
                    Thread.Sleep(lag);
                    SendKeys.Send("{" + choosedPowerDownButton + "}");
                    Thread.Sleep(5);
                }
            }
        }
    }
    
}
