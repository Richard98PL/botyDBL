﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace realDBLMemoryBot
{
    public partial class Form2 : Form
    {
        public ArrayList zdjecia = new ArrayList();
        public Form2()
        {
            InitializeComponent();

           
            zdjecia.Add(pictureBox1);
            zdjecia.Add(pictureBox2);
            zdjecia.Add(pictureBox3);
            zdjecia.Add(pictureBox4);
            zdjecia.Add(pictureBox5);
            zdjecia.Add(pictureBox6);

            foreach(PictureBox x in zdjecia)
            {
                x.Visible = false;
            }

            pictureBox1.Visible = true;
            button2.Enabled = false;


            
        }

        static int ktoryOstatnio = 1;
        private void Button1_Click(object sender, EventArgs e)
        {
            if (ktoryOstatnio == 0)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox1.Visible = true;
            }

            else if (ktoryOstatnio == 1)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox2.Visible = true;
            }

            else if (ktoryOstatnio == 2)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox3.Visible = true;
            }

            else if (ktoryOstatnio == 3)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox4.Visible = true;
            }

            else if (ktoryOstatnio == 4)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox5.Visible = true;
            }

            else if (ktoryOstatnio == 5)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox6.Visible = true;
            }

            ktoryOstatnio++;
            if (ktoryOstatnio == 2) button2.Enabled = true;
            else if (ktoryOstatnio == 6) button1.Enabled = false;
            label1.Text = ktoryOstatnio + "/6";

            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ktoryOstatnio--;
            label1.Text = ktoryOstatnio + "/6";

            if (ktoryOstatnio == 1)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox1.Visible = true;
            }

            else if (ktoryOstatnio == 2)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox2.Visible = true;
            }

            else if (ktoryOstatnio == 3)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox3.Visible = true;
            }

            else if (ktoryOstatnio == 4)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox4.Visible = true;
            }

            else if (ktoryOstatnio == 5)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox5.Visible = true;
            }

            else if (ktoryOstatnio == 6)
            {
                foreach (PictureBox x in zdjecia)
                {
                    x.Visible = false;
                }
                pictureBox6.Visible = true;
            }

            
            if (ktoryOstatnio == 5) button1.Enabled = true;
            if (ktoryOstatnio == 1) button2.Enabled = false;
           
        }
    }
}
