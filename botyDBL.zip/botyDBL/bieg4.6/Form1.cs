﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bieg4._6
{
    public partial class Form1 : Form
    {

        public static Process DBLProcess = Process.GetProcessesByName("DBLClient").FirstOrDefault();


        [DllImport("User32.dll")]
        static extern int SetForegroundWindow(IntPtr point);

        static Random rnd = new Random();
        static int lag;
        public Form1()
        {
            InitializeComponent();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            lag = rnd.Next(0, 100);
            if (DBLProcess != null)
            {
                IntPtr h = DBLProcess.MainWindowHandle;
                SetForegroundWindow(h);
                Thread.Sleep(lag);
                SendKeys.Send("{UP}");
                Thread.Sleep(100);
                SendKeys.Send("{DOWN}");
               
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "go") button1.Text = "stop";
            else button1.Text = "go";

            if (timer1.Enabled) timer1.Enabled = false;
            else timer1.Enabled = true;

            if (timer2.Enabled) timer2.Enabled = false;
            else timer2.Enabled = true;
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
           lag = rnd.Next(0, 100);
            if (DBLProcess != null)
            {
                IntPtr h = DBLProcess.MainWindowHandle;
                SetForegroundWindow(h);
                Thread.Sleep(lag);
                SendKeys.Send("{F10}");
            }
        
        }
    }
}
